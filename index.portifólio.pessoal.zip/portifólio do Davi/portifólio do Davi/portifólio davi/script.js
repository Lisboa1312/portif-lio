

document.querySelectorAll('nav ul li a').forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();
        const href = this.getAttribute('href');
        document.querySelector(href).scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    });
});

const sections = document.querySelectorAll('section');
sections.forEach(section => {
    section.addEventListener('mouseover', () => {
        section.style.backgroundColor = "#f0f0f0";
        section.style.transform = "scale(1.02)";
        section.style.transition = "all 0.3s ease-in-out";
    });

    section.addEventListener('mouseout', () => {
        section.style.backgroundColor = "#fff";
        section.style.transform = "scale(1)";
    });
});


const navLinks = document.querySelectorAll('nav ul li a');
navLinks.forEach(link => {
    link.addEventListener('mouseover', () => {
        link.style.color = "#ffcc00";
        link.style.transition = "color 0.3s ease";
    });

    link.addEventListener('mouseout', () => {
        link.style.color = "rgb(75, 74, 74)";
    });
});

const images = document.querySelectorAll('img');
images.forEach(img => {
    img.addEventListener('mouseover', () => {
        img.style.transform = "scale(1.12)";
        img.style.filter = "brightness(1.2)";
        img.style.transition = "transform 0.3s ease, filter 0.3s ease";
    });

    img.addEventListener('mouseout', () => {
        img.style.transform = "scale(1)";
        img.style.filter = "brightness(1)";
    });
});


window.addEventListener('load', () => {
    const elements = document.querySelectorAll('header, section, footer');
    elements.forEach(el => {
        el.style.opacity = 0;
        el.style.transition = "opacity 2s ease-in-out";
    });

    setTimeout(() => {
        elements.forEach(el => {
            el.style.opacity = 1;
        });
    }, 200);
});


images.forEach(img => {
    img.addEventListener('click', () => {
        img.style.boxShadow = "0px 10px 15px rgba(0, 0, 0, 0.5)";
        img.style.transition = "box-shadow 0.3s ease";
        setTimeout(() => {
            img.style.boxShadow = "none";
        }, 500);
    });
});

const footer = document.querySelector('footer');
footer.addEventListener('mouseover', () => {
    footer.style.backgroundColor = "#7a7a7a";
    footer.style.color = "#ffffff";
    footer.style.transition = "all 0.3s ease-in-out";
});

footer.addEventListener('mouseout', () => {
    footer.style.backgroundColor = "#3d3c3cfd";
    footer.style.color = "rgb(97, 93, 93)";
});